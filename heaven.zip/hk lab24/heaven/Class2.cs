﻿using System;
using Modding;

namespace HeavenMod
{
    [Serializable]
    public class GlobalModSettings : ModSettings
    {
        public bool DoubleSoulCapacity = true;
        public bool DoubleNail = true;
        public bool ThreeSoulGain = true;
        public bool QuickFocus = true;
        public bool ZeroDeamage = true;
        public bool DoubleSpells = true;
        public bool limit = true;
    }
}