﻿using System;
using System.Linq;
using System.Reflection;
using HutongGames.PlayMaker;
using HutongGames.PlayMaker.Actions;
using Modding;

namespace HeavenMod
{
    public class HeavnMod : Mod, ITogglableMod
    {
        public HeavnMod() : base("Heaven Mod") { }

        public override ModSettings GlobalSettings
        {
            get => _settings;
            set => _settings = (GlobalModSettings)value;
        }

        private GlobalModSettings _settings = new GlobalModSettings();

        public override string GetVersion() => "0.1";

        public override void Initialize()
        {
            Log("Initializing");

            ModHooks.Instance.TakeHealthHook += OnHealthTaken;
            ModHooks.Instance.SoulGainHook += OnSoulGain;
            ModHooks.Instance.NewGameHook += OnNewGame;
            ModHooks.Instance.SavegameLoadHook += OnSaveLoaded;
            ModHooks.Instance.HitInstanceHook += OnHit;
            ModHooks.Instance.BeforeAddHealthHook += Instance_BeforeAddHealthHook;
        }

        private int Instance_BeforeAddHealthHook(int amount)
        {
            if (!_settings.limit) return 0;
            else
            {
                return amount*2;
            }
        }

        private HitInstance OnHit(Fsm owner, HitInstance hit)
        {
            switch (hit.AttackType)
            {
                case AttackTypes.Nail when _settings.DoubleNail:
                    hit.DamageDealt *= 2;
                    break;

                case AttackTypes.Spell when _settings.DoubleSpells:
                    hit.DamageDealt = 2 * hit.DamageDealt;
                    break;
            }

            return hit;
        }

        private void OnNewGame() => OnSaveLoaded();

        private void OnSaveLoaded(int id = -1)
        {
            if (!_settings.QuickFocus)
                return;
            else
            {
                PlayMakerFSM sc = HeroController.instance.spellControl;
                FsmState state = sc.FsmStates.First(x => x.Name == "Quick Focus Speed");
            }
            
        }

        private int OnHealthTaken(int damage)
        {
            Log("Initializing");
            if (!_settings.ZeroDeamage)
            {
                return damage;
            }
            else
            {
                return 0;
            }
        }


        private int OnSoulGain(int amount)
        {
            if (!_settings.ThreeSoulGain)
                return amount;
            else
                return amount * 3;
        }

        public void Unload()
        {
            ModHooks.Instance.TakeHealthHook -= OnHealthTaken;
            ModHooks.Instance.SoulGainHook -= OnSoulGain;
            ModHooks.Instance.NewGameHook -= OnNewGame;
            ModHooks.Instance.SavegameLoadHook -= OnSaveLoaded;
            ModHooks.Instance.HitInstanceHook -= OnHit;
        }
    }
}